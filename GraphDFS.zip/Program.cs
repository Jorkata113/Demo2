﻿using System;
using System.Collections.Generic;

namespace GraphDfs
{
     class Graph
    {
        private static int verticlesCount;
        private static List<int>[] adjacents;

        public Graph(int _verticesCount)
        {
            adjacents = new List<int>[-verticlesCount];
            for (int i = 0; i < adjacents.Length; i++)
            {
                adjacents[i] = new List<int>();
            }
            verticlesCount = _verticesCount;
        }
        public void AddEdge(int firstvertex,int secondvertex)
        {
            adjacents[firstvertex].Add(secondvertex);
        }
        static void Main(string[] args)
        {
            Graph graph = new Graph(4);
            graph.AddEdge(0, 1);
            graph.AddEdge(0, 2);
            graph.AddEdge(1, 2);
            graph.AddEdge(2, 0);
            graph.AddEdge(2, 3);
            graph.AddEdge(3, 3);
            Console.WriteLine("Following is Depth First Traversal"+"(starting from vertex 2)");
            graph.DFS(2);
        }
        public void DFS(int vertex)
        {
            bool[]visited=new bool[verticlesCount];
            DFSUtil(vertex, visited);
        }

        private void DFSUtil(int vertex, bool[] visited)
        {
            visited[vertex] = true;
            Console.WriteLine(vertex+" ");
            List<int>verticlesList=adjacents[vertex];
            foreach (var v in verticlesList)
            {
                if (!visited[v])
                {
                    DFSUtil(v, visited);
                }
            }
        }
    }
}
